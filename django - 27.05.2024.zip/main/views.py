from django.shortcuts import render, redirect
from django.http import *
from .models import Users
import time

people = [
    {
        "ism": "Akmal",
        "familiya": "Karimov",
        "yoshi": 28,
        "jinsi": "Erkak",
        "telefon": "+998901234567",
    },
    {
        "ism": "Dilnoza",
        "familiya": "Tursunova",
        "yoshi": 24,
        "jinsi": "Ayol",
        "telefon": "+998901234568",
    },
    {
        "ism": "Sardor",
        "familiya": "Rasulov",
        "yoshi": 30,
        "jinsi": "Erkak",
        "telefon": "+998901234569",
    },
    {
        "ism": "Feruza",
        "familiya": "Ismoilova",
        "yoshi": 26,
        "jinsi": "Ayol",
        "telefon": "+998901234570",
    },
    {
        "ism": "Jasur",
        "familiya": "Norboev",
        "yoshi": 32,
        "jinsi": "Erkak",
        "telefon": "+998901234571",
    },
]


def homePage(request):
    return render(request, "index.html")

def aboutPage(request):
    return render(request, "about.html", {'users': Users.objects.all()})

def contactPage(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        lname = request.POST.get("lname")
        age = request.POST.get("age")
        # print(name, lname, age)
        Users.objects.create(name=name, fname=lname, age=age)
        return redirect("about")
    else:    
        return render(request, "contact.html")
    
def UpdatePage(request, id):
    try:
        users = Users.objects.get(id=id)
        if request.method == 'POST':
            users.name = request.POST.get("name")
            users.fname = request.POST.get("lname")
            users.age = request.POST.get("age")
            users.save()
            return redirect('about')
        
        return render(request, 'update.html', {'cls': Users.objects.get(id=id)})
    except:
        return redirect('about')


def DeletePage(request, id):
    try:
        users = Users.objects.get(id=id)
        users.delete()
        return redirect('about')
    except:
        return redirect('about')
# Create your views here.
